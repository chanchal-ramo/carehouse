// function switchCard() {
//     const loginCard = document.querySelector('.container .card:nth-child(1)');
//     const registerCard = document.querySelector('.container .card:nth-child(2)');
  
//     if (loginCard.style.display === 'none') {
//       loginCard.style.display = 'block';
//       registerCard.style.display = 'none';
//     } else {
//       loginCard.style.display = 'none';
//       registerCard.style.display = 'block';
//     }
//   }
  function switchCard() {
    var loginCard = document.getElementById("login-card");
    var registerCard = document.getElementById("register-card");

    if (loginCard.style.display === "block") {
        loginCard.style.display = "none";
        registerCard.style.display = "block";
    } else {
        loginCard.style.display = "block";
        registerCard.style.display = "none";
    }
}

function showForgetPassword() {
    // Add your logic for handling the "Forgot Password?" functionality
    alert("Forgot Password? Implement your logic here.");
}
