// var timer = 60; // Time in seconds
//     var interval;

//     function startTimer() {
//         var timerDisplay = document.getElementById("timer");
//         var resendBtn = document.getElementById("resendBtn");

//         interval = setInterval(function() {
//             timer--;
//             timerDisplay.innerText = "" + timer + " seconds";

//             if (timer <= 0) {
//                 clearInterval(interval);
//                 timerDisplay.innerText = "";
//                 resendBtn.disabled = false;
//             }
//         }, 1000);
//     }

//     startTimer();

//     document.addEventListener("DOMContentLoaded", function() {
//         const resendBtn = document.getElementById("resend-btn");
//         const timerDiv = document.getElementById("timer");
//         let timeLeft = 60;
      
//         function updateTimer() {
//           timerDiv.innerText = `resend otp ${timeLeft} seconds`;
//           if (timeLeft === 0) {
//             clearInterval(timerInterval);
//             timerDiv.innerText = "";
//             resendBtn.disabled = false;
//           }
//           timeLeft--;
//         }
      
//         resendBtn.addEventListener("click", function() {
//           resendBtn.disabled = true;
//           timeLeft = 60;
//           updateTimer();
//           const timerInterval = setInterval(updateTimer, 1000);
//         });
//       });
      // Countdown timer for resend OTP
// var countdown = 60;
// var timer = setInterval(function() {
//   countdown--;
//   document.getElementById('countdown').textContent = countdown;
//   if (countdown <= 0) {
//     clearInterval(timer);
//     document.getElementById('countdown').textContent = 'Expired';
//   }
// }, 1000);

var countdown = 60;
var timer = setInterval(function() {
  countdown--;
  document.getElementById('countdown').textContent = countdown;
  if (countdown <= 0) {
    clearInterval(timer);
    document.getElementById('countdown').textContent = 'Expired';
    document.getElementById('resendLink').style.pointerEvents = 'auto'; // Enable link when timer expires
  }
}, 1000);

// Function to resend OTP
document.getElementById('resendLink').addEventListener('click', function(event) {
  event.preventDefault(); // Prevent default behavior of anchor tag
  countdown = 60; // Reset countdown
  document.getElementById('countdown').textContent = countdown; // Update countdown display
  this.style.pointerEvents = 'none'; // Disable link until timer expires
  timer = setInterval(function() {
    countdown--;
    document.getElementById('countdown').textContent = countdown;
    if (countdown <= 0) {
      clearInterval(timer);
      document.getElementById('countdown').textContent = 'Expired';
      document.getElementById('resendLink').style.pointerEvents = 'auto'; // Enable link when timer expires
    }
  }, 1000);
});
const otpInput = document.getElementById('otp');
const submitBtn = document.getElementById('submit-btn');

otpInput.addEventListener('click', () => {
  submitBtn.style.marginTop = '30px'; // Adjust margin as needed
});

otpInput.addEventListener('blur', () => {
  submitBtn.style.marginTop = '350px'; // Reset margin when focus is lost
});
