function togglePassword(inputId) {
    var passwordInput = document.getElementById(inputId);
    var toggleIcon = document.querySelector(`#${inputId} + .toggle-password`);

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        toggleIcon.style.backgroundImage = "url('eye-off-icon.png')"; /* Replace with your eye-off icon image */
    } else {
        passwordInput.type = "password";
        toggleIcon.style.backgroundImage = "url('eye-icon.png')"; /* Replace with your eye icon image */
    }
}
