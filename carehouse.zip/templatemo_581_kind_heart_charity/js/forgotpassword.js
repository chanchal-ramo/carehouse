// JavaScript for Forgot Password Form

// Function to simulate sending a verification code
function sendVerificationCode() {
    // Implement logic to send the verification code (e.g., through an API call)
    alert("Verification code sent successfully! Check your email or phone.");
}

// Function to switch between login and registration cards
function switchCard() {
    // Toggle the display of login and registration cards
    var loginCard = document.querySelector('.card:nth-child(1)');
    var registrationCard = document.querySelector('.card:nth-child(2)');

    if (loginCard.style.display !== 'none') {
        loginCard.style.display = 'none';
        registrationCard.style.display = 'block';
    } else {
        loginCard.style.display = 'block';
        registrationCard.style.display = 'none';
    }
}

// Add more functions as needed for form validation, API calls, etc.
