function previewDoctorImage() {
    var input = document.getElementById('doctorImage');
    var preview = document.getElementById('doctorImagePreview');

    while (preview.firstChild) {
        preview.removeChild(preview.firstChild);
    }

    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            var image = document.createElement('img');
            image.src = e.target.result;
            preview.appendChild(image);
        };

        reader.readAsDataURL(input.files[0]);
    }
}

function submitForm() {
    // Add your form submission logic here
    alert("Form submitted!");
}
