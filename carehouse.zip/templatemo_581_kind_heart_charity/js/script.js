function submitForm() {
    // Add your validation logic here before submitting the form
    // For simplicity, validation is not implemented in this example
    document.getElementById('registrationForm').submit();
  }
  